# Maxwell Liaram — Data Analytics Career Pack

**Data Analyst | IT Support Specialist | Software Development**  
Narok, Kenya · [LinkedIn](https://www.linkedin.com/in/maxwell-liaram-6227a3382) · [GitHub](https://github.com/maxwellliaram-hue)

## Career profile
ICT professional with experience in data analysis, IT support, software development and conservation data management. I work with Python, pandas, NumPy, SQL/SQLite, Excel and data visualisation to clean datasets, analyse operational performance and communicate actionable findings.

## Selected data analytics portfolio

| Project | Focus | Selected result |
|---|---|---|
| [PLP Capstone — Duka Electronics](https://github.com/maxwellliaram-hue/plp-capstone-a-maxwell-liaram) | End-to-end data cleaning, EDA, SQL, statistical testing and reporting | Analysed H1 2026 synthetic sales data totalling KES 350.9M; Q2 revenue was 1.3% below Q1, with regional movements from Eldoret (+74%) to Mombasa (-27%) and Nakuru (-29%). |
| [PesaPap Growth Analytics (A7)](https://github.com/maxwellliaram-hue/plp-da-a7-pesapap-growth-analytics) | SQL KPIs, RFM, cohorts and onboarding A/B test | In synthetic experiment data, simplified onboarding converted 13.8% vs 10.5% (+3.3 percentage points; chi-square p=0.005). |
| [Duka Board Report (A6)](https://github.com/maxwellliaram-hue/plp-da-a6-duka-board-report) | Executive reporting and visual storytelling | Summarised 1,000 synthetic orders worth KES 30.76M; three big-ticket products contributed 68.4% of revenue. |
| [Student Performance EDA (A5)](https://github.com/maxwellliaram-hue/plp-da-a5-student-performance-eda) | Exploratory analysis and hypothesis-led insights | Analysed 1,200 synthetic learner records; study hours had the strongest measured correlation with score (r=0.70). |
| [Agent Data Clean-up (A4)](https://github.com/maxwellliaram-hue/plp-da-a4-agent-data-cleanup) | Reproducible data quality pipeline | Reduced 2,075 raw synthetic transaction rows to 1,948 cleaned rows and documented removals, imputations and outlier flags. |
| [Duka Sales Exploration (A3)](https://github.com/maxwellliaram-hue/plp-da-a3-duka-sales-exploration) | Sales EDA and Excel validation | Analysed 1,000 synthetic orders totalling KES 30.76M and cross-checked pandas results against Excel formulas and a PivotTable. |
| [Rainfall Advisory (A2)](https://github.com/maxwellliaram-hue/plp-da-a2-rainfall-advisory) | Rainfall data cleaning and planting-window analysis | Compared monthly rainfall patterns across five counties; flagged a handwritten-data quality issue in the Machakos record. |
| [Gikomba Stall Analysis (A1)](https://github.com/maxwellliaram-hue/-plp-da-a1-gikomba-stall-analysis) | Small-business sales analysis | Analysed 14 days of sample sales (KES 46,450); week-two sales were 10.66% higher than week one. |

> **Data note:** The PLP portfolio projects above use generated/synthetic datasets where stated in the project repositories. Their results demonstrate analytical workflow and should not be presented as verified commercial client outcomes.

## Technical toolkit
- **Analysis:** Python, pandas, NumPy, SciPy, Excel
- **Databases:** SQL, SQLite, relational data modelling
- **Communication:** Matplotlib, Seaborn, KPI scorecards, executive summaries, Looker Studio
- **Workflow:** Jupyter Notebook, Git, GitHub, data validation and reproducible cleaning pipelines

## Career documents
- [CV (PDF)](cv/Maxwell_Liaram_CV.pdf)
- [Technical interview preparation](interview_prep.md)
- [Mock interview reflection](mock_interview_reflection.md)

## Professional links
- GitHub: https://github.com/maxwellliaram-hue
- LinkedIn: https://www.linkedin.com/in/maxwell-liaram-6227a3382
- Capstone repository: https://github.com/maxwellliaram-hue/plp-capstone-a-maxwell-liaram

## LinkedIn capstone post
A draft post is included at the end of [interview_prep.md](interview_prep.md) for review and publication. Add the published post URL here after posting.

## Portfolio curation checklist
- [ ] Pin the capstone repository and two strongest supporting projects on GitHub.
- [ ] Review A1–A7 READMEs for screenshots, setup instructions, limitations and clear findings.
- [ ] Publish the capstone post on LinkedIn and add its URL above.
- [ ] Complete a 20-minute mock interview with a peer or mentor and replace the pending reflection with actual feedback.
