# Mock Interview Reflection — Maxwell Liaram

> **Status: pending completion.** This document is a preparation template, not a record of an interview that has already happened. Complete it after conducting the required 20-minute mock interview with a peer or mentor.

## Interview details
- **Interviewer / peer / mentor:** [Add actual name]
- **Date:** [Add actual date]
- **Role or focus:** Junior Data Analyst
- **Duration:** 20 minutes
- **Format:** [In person / video / phone]

## Wins
After the interview, record two or three specific moments that went well. Consider:
- Explaining the difference between INNER JOIN and LEFT JOIN with a practical data-quality example.
- Describing a reproducible cleaning workflow and how you document imputation and exclusions.
- Explaining why correlation does not establish causation.
- Communicating an analytical result in business language, with assumptions and limitations.

**Actual examples / interviewer feedback:**  
[Replace this prompt with what happened. Do not leave generic examples as claimed wins.]

## Areas to improve
Record the specific questions where the answer was incomplete, unclear or too long.

| Area | What happened | Improvement |
|---|---|---|
| SQL joins and aggregations | [Actual feedback] | Practise explaining join choice, GROUP BY, HAVING and window functions using a small schema. |
| Statistics and experiments | [Actual feedback] | Practise interpreting p-values, confidence intervals, effect size, randomisation and sample-ratio checks. |
| Data storytelling | [Actual feedback] | Answer with finding → evidence → business implication → caveat. |
| STAR delivery | [Actual feedback] | Keep each story structured and concise; quantify the result and distinguish synthetic project data from workplace outcomes. |

## Concrete practice plan
1. **Day 1 — SQL (30 minutes):** Write and explain five queries using JOIN, GROUP BY, HAVING, CASE and a window function. Check results against expected row counts.
2. **Day 2 — Python/data quality (30 minutes):** Take a small CSV, profile missing values and duplicates, clean it with pandas, and explain each rule and its impact.
3. **Day 3 — Statistics (30 minutes):** Explain correlation vs causation, a confidence interval, a chi-square test and one A/B-test limitation without notes.
4. **Day 4 — Storytelling (20 minutes):** Present the Duka capstone in a two-minute executive summary, including one recommendation and one limitation.
5. **Day 5 — STAR practice (20 minutes):** Rehearse the data-cleaning and sales-analysis stories; ask a peer to score clarity, evidence and concision.
6. **Follow-up mock (20 minutes):** Repeat the interview and compare the feedback against the first session.

## Reflection after the session
- **My strongest answer:** [Add]
- **The question I struggled with most:** [Add]
- **One change I will make next time:** [Add]
- **Interviewer’s overall feedback:** [Add]
