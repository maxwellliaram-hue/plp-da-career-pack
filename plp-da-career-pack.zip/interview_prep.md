# Data Analytics Interview Preparation — Maxwell Liaram

## 1. What is the difference between INNER JOIN and LEFT JOIN?
An `INNER JOIN` returns only rows with matching keys in both tables. A `LEFT JOIN` retains every row from the left table and adds matching columns from the right; unmatched right-side values become `NULL`. I choose based on the business question. For example, when checking whether every transaction belongs to a known agent, a `LEFT JOIN` from transactions to agents exposes unmatched agent IDs instead of silently dropping those transactions.

## 2. How do you handle missing values and duplicates?
I first profile the fields and quantify missingness and duplicate keys, then determine whether each issue is valid, recoverable or should be excluded. I document the rule, preserve an audit trail and compare row counts before and after. In my mobile-money agent clean-up project, I removed exact and conflicting duplicate transaction IDs, dropped rows missing essential fields, imputed selected missing amounts by transaction type with an imputation flag, and retained/flagged outliers for review rather than deleting them automatically.

## 3. What is the difference between correlation and causation?
Correlation measures the strength and direction of association between variables; it does not prove that one variable causes the other. Confounding variables, selection effects and reverse causality may explain an observed relationship. In the student-performance EDA, study hours correlated with scores (r=0.70), but the dataset was observational and synthetic, so I described this as an association—not proof that increasing study hours alone causes higher scores.

## 4. How would you evaluate an A/B test?
I would define the hypothesis, primary metric, eligible population, randomisation unit, sample-size requirement and test duration before looking at results. I would check assignment balance, data quality, exposure and guardrail metrics, then compare conversion rates with an appropriate statistical test and confidence interval. I would report both absolute and relative lift, practical impact and limitations. In the PesaPap synthetic project, variant B converted at 13.8% versus 10.5% (+3.3 percentage points); the chi-square p-value was 0.005. The sample-ratio check was also flagged, so the result warrants a holdout and follow-up validation rather than an unqualified claim.

## 5. How do you communicate analysis to non-technical stakeholders?
I start with the decision the audience needs to make, lead with the main finding, quantify its scale, explain the recommended action and state assumptions/limitations. I use a small number of clearly titled charts and avoid unexplained technical terms. In the Duka Electronics board-report project, I focused the narrative on the dependence on three big-ticket products, the relative performance of branches and a clearly labelled what-if opportunity for Nakuru. I distinguished revenue from profit and a scenario from a forecast.

## STAR story 1 — Improving data quality
**Situation:** A mobile-money agent dataset contained duplicate transactions, missing fields, inconsistent formats and records that did not match the agent reference table.  
**Task:** Prepare an analysis-ready dataset while making quality decisions transparent.  
**Action:** I built a repeatable Python cleaning pipeline, applied explicit completeness, validity, uniqueness, consistency and timeliness rules, logged row counts, flagged imputed values/outliers and retained unmatched-agent transactions with an `Unknown` county for follow-up.  
**Result:** The synthetic transaction extract went from 2,075 rows to 1,948 cleaned rows. The pipeline documented 127 removals, 56 imputed amounts, 114 outlier flags and 38 transactions linked to unknown agents. This made the output auditable and highlighted issues requiring source-system follow-up.

## STAR story 2 — Turning sales analysis into a decision
**Situation:** A retail sales dataset needed to be translated into clear priorities for a management audience.  
**Task:** Explain the key drivers and propose practical next steps from the H1 2026 sales analysis.  
**Action:** I cleaned and analysed order-level data using Python and SQL, compared product and branch performance, tested regional changes and built a concise stakeholder report.  
**Result:** In the synthetic capstone dataset, revenue was KES 350.9M and Q2 was 1.3% below Q1, masking divergent regional trends: Eldoret +74%, Mombasa -27% and Nakuru -29%. Smartphones and laptops represented 22% of order lines but 73% of revenue. The analysis supported targeted follow-up rather than treating all branches alike. These are simulated-data findings, not verified client results.

---

## LinkedIn capstone post — draft (publish manually)

I’m excited to share my PLP Data Analytics capstone: **Duka Electronics Sales Performance Analysis (H1 2026)**.

I used Python (pandas, NumPy, Matplotlib, Seaborn and SciPy), SQL/SQLite and reporting tools to clean and analyse sales data, build KPIs, investigate regional performance and communicate recommendations.

A few findings from the project’s synthetic dataset:
- H1 revenue totalled KES 350.9M, with Q2 1.3% below Q1.
- Regional performance varied: Eldoret grew 74%, while Mombasa and Nakuru declined 27% and 29%.
- Smartphones and laptops represented 22% of order lines but 73% of revenue.

The project strengthened my skills in data quality, exploratory analysis, SQL, statistical testing and stakeholder communication. The dataset is synthetic, and the findings are presented as a demonstration of analytical methods.

Explore the project: https://github.com/maxwellliaram-hue/plp-capstone-a-maxwell-liaram

I welcome feedback and opportunities to apply data analytics to real operational and business challenges.

#DataAnalytics #Python #SQL #PowerLearnProject #DataVisualization
